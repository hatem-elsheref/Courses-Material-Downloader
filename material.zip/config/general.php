<?php
return [
    'application_name'=>'Material',
    'application_name_mini'=>'M',
    'logo'=>'app_logo.png',
    'social_links'=>[
        'facebook'  =>'#',
        'twitter'   =>'#',
        'instagram'  =>'#',
    ],
    'bio'=>'Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.',
    'address'=>'666 5th Ave New York, NY, United',
        'phone'=>'tel:+1.11.85412542',
    'email'=>'mailto:info@canvas.com',
    'website'=>'716-298-1822',
    'lan'=>'90.3854',
    'lat'=>'23.7286'
];
