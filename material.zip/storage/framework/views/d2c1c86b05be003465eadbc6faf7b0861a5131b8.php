<?php $__env->startSection('bread'); ?>
    <h1>All Instructors</h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Instructors</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="row">

            <div class="col-xs-12">
                <a href="<?php echo e(route('instructor.create')); ?>" class="btn  btn-primary d-block" style="margin-bottom: 5px"><span class="fa fa-plus"></span> Add New Instructor </a>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Instructors <span class="badge badge-success"><?php echo e($instructors->count()); ?></span></h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <tbody><tr>
                                <th>ID</th>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Job</th>
                                <th>Courses</th>
                                <th>Actions</th>
                            </tr>
                            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><img src="<?php echo e(uploadedAssets($item->photo)); ?>" style="width: 45px;height: 45px"></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->job); ?></td>
                                    <td><?php echo e($item->courses->count()); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-danger" onclick="RemoveItem('item-<?php echo e($item->id); ?>')"> <i class="fa fa-trash"></i>   Remove </button>
                                        <a href="<?php echo e(route('instructor.edit',$item->id)); ?>" class="btn btn-sm btn-success"><i class="fa fa-edit"></i>  Edit </a>
                                        <a href="<?php echo e(route('instructor.show',$item->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-eys"></i>  View Courses </a>
                                    </td>
                                    <form action="<?php echo e(route('instructor.destroy',$item->id)); ?>" id="item-<?php echo e($item->id); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> </form>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody></table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/el-sheref/Desktop/Eng_Mahmoud_Holah/material/resources/views/dashboard/instructors/index.blade.php ENDPATH**/ ?>